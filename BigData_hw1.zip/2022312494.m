clear all;clc;
close all;
AverageAge=xlsread('D:\DataAnalysis\HW1\data.xlsx','data','G1:G2041');%����col[7]
%% ����3a
a1=min(AverageAge);%��Сֵ
a2=max(AverageAge);%���ֵ
a3=mean(AverageAge);%ƽ��ֵ
a4=median(AverageAge);%��λ��
skewness_age=skewness(AverageAge);
kurtosis_age=kurtosis(AverageAge);
fig=figure;
[age,x_center]=hist(AverageAge,30);%��30�飬����Ƶ������������
age=age/length(AverageAge);%Ƶ��
fig1=bar(x_center,age,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
axis ([10 45 0 0.12]);
hold on;
[pdf,x_position]=ksdensity(AverageAge);
fig2=plot (x_position,pdf,'LineWidth',2);
xlabel('Average age');
ylabel('Empirical PDF');
txt_age=text(13,0.1,{['Min: ',num2str(a1)];['Max: ',num2str(a2)];['Mean: ',num2str(a3)];['Kurtosis: ',num2str(kurtosis_age)];['Skewness: ',num2str(skewness_age)]},'fontsize',10);
[h1,p1]=kstest(AverageAge);
[h2,p2]=jbtest(AverageAge);
[h3,p3] = lillietest(AverageAge);
%% ����3b
cate1=AverageAge(1:484);
cate2=AverageAge(485:784);
cate3=AverageAge(785:980);
cate4=AverageAge(981:1405);
cate5=AverageAge(1406:2040);
%% 3b1
cate1_min=min(cate1);
cate1_max=max(cate1);
cate1_mean=mean(cate1);
cate1_var=var(cate1);
cate1_std=std(cate1);
cate1_skewness=skewness(cate1);
cate1_kurtosis=kurtosis(cate1);
fig=figure;
[c1,x1]=hist(cate1,20);%��20�飬����Ƶ������������
c1=c1/length(cate1);%Ƶ��
fig1=bar(x1,c1,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
% axis ([10 45 0 0.12]);
hold on;
[pdf1,x_1]=ksdensity(cate1);
fig2=plot(x_1,pdf1,'LineWidth',2);
xlabel('Average age (category 1)');
ylabel('Empirical PDF');
txt_age=text(8,0.11,{['Min: ',num2str(cate1_min)];['Max: ',num2str(cate1_max)];['Mean: ',num2str(cate1_mean)];['Kurtosis: ',num2str(cate1_kurtosis)];['Skewness: ',num2str(cate1_skewness)]},'fontsize',10);
[h_1,p_1]=kstest(cate1);
%% 3b2
cate2_min=min(cate2);
cate2_max=max(cate2);
cate2_mean=mean(cate2);
cate2_var=var(cate2);
cate2_std=std(cate2);
cate2_skewness=skewness(cate2);
cate2_kurtosis=kurtosis(cate2);
fig=figure;
[c2,x2]=hist(cate2,20);%��20�飬����Ƶ������������
c2=c2/length(cate2);%Ƶ��
fig1=bar(x2,c2,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
hold on;
[pdf2,x_2]=ksdensity(cate2);
fig2=plot(x_2,pdf2,'LineWidth',2);
xlabel('Average age (category 2)');
ylabel('Empirical PDF');
txt_age=text(13,0.1,{['Min: ',num2str(cate2_min)];['Max: ',num2str(cate2_max)];['Mean: ',num2str(cate2_mean)];['Kurtosis: ',num2str(cate2_kurtosis)];['Skewness: ',num2str(cate2_skewness)]},'fontsize',10);
[h_2,p_2]=kstest(cate2);
%% 3b3
cate3_min=min(cate3);
cate3_max=max(cate3);
cate3_mean=mean(cate3);
cate3_var=var(cate3);
cate3_std=std(cate3);
cate3_skewness=skewness(cate3);
cate3_kurtosis=kurtosis(cate3);
fig=figure;
[c3,x3]=hist(cate3,20);%��20�飬����Ƶ������������
c3=c3/length(cate3);%Ƶ��
fig1=bar(x3,c3,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
hold on;
[pdf3,x_3]=ksdensity(cate3);
fig2=plot(x_3,pdf3,'LineWidth',2);
xlabel('Average age (category 3)');
ylabel('Empirical PDF');
txt_age=text(37,0.1,{['Min: ',num2str(cate3_min)];['Max: ',num2str(cate3_max)];['Mean: ',num2str(cate3_mean)];['Kurtosis: ',num2str(cate3_kurtosis)];['Skewness: ',num2str(cate3_skewness)]},'fontsize',10);
[h_3,p_3]=kstest(cate3);
%% 3b4
cate4_min=min(cate4);
cate4_max=max(cate4);
cate4_mean=mean(cate4);
cate4_var=var(cate4);
cate4_std=std(cate4);
cate4_skewness=skewness(cate4);
cate4_kurtosis=kurtosis(cate4);
fig=figure;
[c4,x4]=hist(cate4,20);%��20�飬����Ƶ������������
c4=c4/length(cate4);%Ƶ��
fig1=bar(x4,c4,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
hold on;
[pdf4,x_4]=ksdensity(cate4);
fig2=plot(x_4,pdf4,'LineWidth',2);
xlabel('Average age (category 4)');
ylabel('Empirical PDF');
txt_age=text(37,0.1,{['Min: ',num2str(cate4_min)];['Max: ',num2str(cate4_max)];['Mean: ',num2str(cate4_mean)];['Kurtosis: ',num2str(cate4_kurtosis)];['Skewness: ',num2str(cate4_skewness)]},'fontsize',10);
[h_4,p_4]=kstest(cate4);
%% 3b5
cate5_min=min(cate5);
cate5_max=max(cate5);
cate5_mean=mean(cate5);
cate5_var=var(cate5);
cate5_std=std(cate5);
cate5_skewness=skewness(cate5);
cate5_kurtosis=kurtosis(cate5);
fig=figure;
[c5,x5]=hist(cate5,20);%��20�飬����Ƶ������������
c5=c5/length(cate5);%Ƶ��
fig1=bar(x5,c5,1);%����ͼ,����Ϊ1���������ΪƵ���ܶ�
hold on;
[pdf5,x_5]=ksdensity(cate5);
fig2=plot(x_5,pdf5,'LineWidth',2);
xlabel('Average age (category 5)');
ylabel('Empirical PDF');
txt_age=text(15,0.2,{['Min: ',num2str(cate5_min)];['Max: ',num2str(cate5_max)];['Mean: ',num2str(cate5_mean)];['Kurtosis: ',num2str(cate5_kurtosis)];['Skewness: ',num2str(cate5_skewness)]},'fontsize',10);
[h_5,p_5]=kstest(cate5);
%%
normplot(AverageAge);%������̬��
h1=lillietest(AverageAge,0.05);
h2=jbtest(AverageAge,0.05);
%% ����3C ANOVA
data=xlsread('D:\DataAnalysis\HW1\data.xlsx','data');
boxplot(data(:,7),data(:,2));%��������ͼ
xlabel('Category')
ylabel('Average age')
mean =[cate1_mean,cate2_mean,cate3_mean,cate4_mean,cate5_mean]
hold on
plot(mean,'-o')
hold off
legend(['Average age mean'])
ssb=length(cate1)*(cate1_mean-a3)^2+length(cate2)*(cate2_mean-a3)^2+length(cate3)*(cate3_mean-a3)^2+length(cate4)*(cate4_mean-a3)^2+length(cate5)*(cate5_mean-a3)^2;
ssw=0;
for i= 1:length(cate1)
    ssw=ssw+(cate1(i)-cate1_mean)^2
end
for i= 1:length(cate2)
    ssw=ssw+(cate2(i)-cate2_mean)^2
end
for i= 1:length(cate3)
    ssw=ssw+(cate3(i)-cate3_mean)^2
end
for i= 1:length(cate4)
    ssw=ssw+(cate4(i)-cate4_mean)^2
end
for i= 1:length(cate5)
    ssw=ssw+(cate5(i)-cate5_mean)^2
end
total=ssb+ssw;
msb=ssb/4;
msw=ssw/2035;
F=msb/msw;
p=1-fcdf(F,4,2035);
%% ����4a
H=xlsread('D:\DataAnalysis\HW1\data.xlsx','4a');%�����޳���������
X=H(:,1);
X=[ones(size(X)),X];
Y=H(:,2:4);
[beta,Sigma,E,CovB,logL] = mvregress(X,Y);%�����betaϵ��������(X'*X)^(-1)*(X'*Y)һ��
s=cov(E);
%% ����4b
H1=xlsread('D:\DataAnalysis\HW1\data.xlsx','data','C1:N2041');%��������
w=H1(:,9);
W=diag(w);
x=H1(:,1:8);
x=[ones(size(w)),x];
y=H1(:,10:12);
B=(x'*W*x)^(-1)*(x'*W*y)%��ع�ϵ��
%% ����4c python code (����Ҫ�����һ���ļ��ȫ��ע�ͱ�ʾ)
% import pandas as pd
% import statsmodels.api as sm
% import pylab as pl
% import numpy as np
% from sklearn import model_selection
% df=pd.read_excel(r'D:\DataAnalysis\HW1\data.xlsx',sheet_name='data',index_col='Ⱥ���')
% data1=df.loc[[1,4],'Ⱥ����':'ͼƬ����']
% data1['������']=1.0
% data1['Ⱥ���']=data1.index
% data1.loc[4,'Ⱥ���']=0
% print (data1)
% print (data1.head())
% print (data1.describe())
% print(data1.columns)
% # ����ѵ���������Լ�
% data_train,data_test=model_selection.train_test_split(data1,test_size=0.2)
% print (data_train)
% print (data_test)
% print (data_train.describe())
% data_train.hist()
% #pl.show()
% train_col=data_train.columns[0:13]
% logit=sm.Logit(data_train['Ⱥ���'],data_train[train_col])
% result=logit.fit()
% #print(result.summary())
% #print(result.conf_int())
% #print(np.exp(result.params))
% data_test['Ԥ�����']=result.predict(data_test[data_test.columns[0:13]])
% print(data_test)
% #Ԥ��׼ȷ��
% hit=0
% total=0
% for value in data_test.values:
%     predict = value[-1]
%     print(predict)
%     category=int(value[-2])
%     print(category)
%     if predict >= 0.5:
%        total += 1
%        if category ==1:
%            hit += 1
% print(hit)
% print(total)
% print(hit/total)
%% ����4c,�������߼��ع飬matlab�Դ�����
clear all;
H2=xlsread('D:\DataAnalysis\HW1\data.xlsx','data','B1:N2041');%��������
H3=[H2(1:484,:);H2(981:1405,:)];%��ñ�ǩΪ1��4������
H3(485:end,1)=0;%����4��0
randIndex=randperm(size(H3,1));%����һ��������У���Χ��1�����������
data=H3(randIndex,:);%����˳��
%80%����ѵ������20%���Լ�
t=round(0.8*size(data,1));
label_train=data(1:t,1);
feature_train=data(1:t,2:end);
label_val=data(t+1:end,1);
feature_val=data(t+1:end,2:end);
w=glmfit(feature_train,label_train,'binomial','link','logit');%�Դ�����
x=[ones(t,1), feature_train]
p_train=1./(1+exp(-x*w));
train=[label_train,p_train];
x_1=[ones(length(label_val),1), feature_val]
p_val=1./(1+exp(-x_1*w));
val=[label_val,p_val];
acc=0;
for i=1:size(val,1)
    if val(i,2)>0.5 && val(i,1)==1
        acc=acc+1;
    end
    if val(i,2)<=0.5 && val(i,1)==0
        acc=acc+1;
    end
end 
l=acc/(909-t);
%% ����5 sampling
clear all;
clc;
data=xlsread('D:\DataAnalysis\HW1\data.xlsx','data');
category_age=[data(:,2),data(:,7)]
%% simple random sampling
for j=1:10
A=category_age(randperm(size(category_age,1), 204),:)
m=mean(A(:,2))
group1=A(:,1)==1
m1=mean(A(group1,2));
m2=mean(A(A(:,1)==2,2));
m3=mean(A(A(:,1)==3,2));
m4=mean(A(A(:,1)==4,2));
m5=mean(A(A(:,1)==5,2));
ssb=size(A(A(:,1)==5,2),1)*(m5-m)^2+size(A(A(:,1)==4,2),1)*(m4-m)^2+size(A(A(:,1)==3,2),1)*(m3-m)^2+size(A(A(:,1)==2,2),1)*(m2-m)^2+size(A(A(:,1)==1,2),1)*(m1-m)^2;
ssw=0;
g5=A(A(:,1)==5,2);
g4=A(A(:,1)==4,2);
g3=A(A(:,1)==3,2);
g2=A(A(:,1)==2,2);
g1=A(A(:,1)==1,2);
for i= 1:size(g5,1)
    ssw=ssw+(g5(i)-m5)^2
end
for i= 1:size(g4,1)
    ssw=ssw+(g4(i)-m4)^2
end
for i= 1:size(g3,1)
    ssw=ssw+(g3(i)-m3)^2
end
for i= 1:size(g2,1)
    ssw=ssw+(g2(i)-m2)^2
end
for i= 1:size(g1,1)
    ssw=ssw+(g1(i)-m1)^2
end
total=ssb+ssw
df_b=4;
df_w=size(A,1)-5;
msb=ssb/df_b;
msw=ssw/df_w;
F(j)=msb/msw;
end
m_F=mean(F)
std_F=std(F)
%% systematic random smpling 
for j=1:10
initial=round(rand(1,1)*2039)+1;
step=10;
A=[]
for i=-204:1:204
if initial+step*i >0
    if initial+step*i<2041
       A=[A;category_age(initial+step*i,:)]
    end
end
end
m=mean(A(:,2))
group1=A(:,1)==1
m1=mean(A(group1,2));
m2=mean(A(A(:,1)==2,2));
m3=mean(A(A(:,1)==3,2));
m4=mean(A(A(:,1)==4,2));
m5=mean(A(A(:,1)==5,2));
ssb=size(A(A(:,1)==5,2),1)*(m5-m)^2+size(A(A(:,1)==4,2),1)*(m4-m)^2+size(A(A(:,1)==3,2),1)*(m3-m)^2+size(A(A(:,1)==2,2),1)*(m2-m)^2+size(A(A(:,1)==1,2),1)*(m1-m)^2;
ssw=0;
g5=A(A(:,1)==5,2);
g4=A(A(:,1)==4,2);
g3=A(A(:,1)==3,2);
g2=A(A(:,1)==2,2);
g1=A(A(:,1)==1,2);
for i= 1:size(g5,1)
    ssw=ssw+(g5(i)-m5)^2
end
for i= 1:size(g4,1)
    ssw=ssw+(g4(i)-m4)^2
end
for i= 1:size(g3,1)
    ssw=ssw+(g3(i)-m3)^2
end
for i= 1:size(g2,1)
    ssw=ssw+(g2(i)-m2)^2
end
for i= 1:size(g1,1)
    ssw=ssw+(g1(i)-m1)^2
end
total=ssb+ssw
df_b=4;
df_w=size(A,1)-5;
msb=ssb/df_b;
msw=ssw/df_w;
F(j)=msb/msw;
end
m_F=mean(F);
std_F=std(F);
%% stratified random sampling
for j=1:10
index=category_age(:,1)==1
A1=category_age(category_age(:,1)==1,:)
A2=category_age(category_age(:,1)==2,:)
A3=category_age(category_age(:,1)==3,:)
A4=category_age(category_age(:,1)==4,:)
A5=category_age(category_age(:,1)==5,:)
A=[A1(randperm(484,48),:);A2(randperm(300,30),:);A3(randperm(196,20),:);A4(randperm(425,43),:);A5(randperm(635,63),:)]
m=mean(A(:,2))
group1=A(:,1)==1
m1=mean(A(group1,2));
m2=mean(A(A(:,1)==2,2));
m3=mean(A(A(:,1)==3,2));
m4=mean(A(A(:,1)==4,2));
m5=mean(A(A(:,1)==5,2));
ssb=size(A(A(:,1)==5,2),1)*(m5-m)^2+size(A(A(:,1)==4,2),1)*(m4-m)^2+size(A(A(:,1)==3,2),1)*(m3-m)^2+size(A(A(:,1)==2,2),1)*(m2-m)^2+size(A(A(:,1)==1,2),1)*(m1-m)^2;
ssw=0;
g5=A(A(:,1)==5,2);
g4=A(A(:,1)==4,2);
g3=A(A(:,1)==3,2);
g2=A(A(:,1)==2,2);
g1=A(A(:,1)==1,2);
for i= 1:size(g5,1)
    ssw=ssw+(g5(i)-m5)^2
end
for i= 1:size(g4,1)
    ssw=ssw+(g4(i)-m4)^2
end
for i= 1:size(g3,1)
    ssw=ssw+(g3(i)-m3)^2
end
for i= 1:size(g2,1)
    ssw=ssw+(g2(i)-m2)^2
end
for i= 1:size(g1,1)
    ssw=ssw+(g1(i)-m1)^2
end
total=ssb+ssw
df_b=4;
df_w=size(A,1)-5;
msb=ssb/df_b;
msw=ssw/df_w;
F(j)=msb/msw;
end
m_F=mean(F);
std_F=std(F);
%%