%% Data pre-processing 
clear;
tic
X_train=[];
X_test=[];
user=load('users.txt');
T=readtable('netflix_train.txt');
d = yyyymmdd(table2array(T(:,4)));
T=table2array(T(:,1:3));
T=[T,d];
P=readtable('netflix_test.txt');
D = yyyymmdd(table2array(P(:,4)));
P=table2array(P(:,1:3));
P=[P,D];
n=0
for i=1:10000
    m=find(T(:,1)==user(i));
    l=find(P(:,1)==user(i));
    X_train(i,T(m,2))=T(m,3);
    X_test(i,P(l,2))=P(l,3);
    n=n+1
end
toc
%% �����û���Эͬ����
tic
A=X_train;
A(A>0)=1;
m=vecnorm(X_train');
d=m'*m;
H=X_train*X_train';
sim0=H./d;
sim1=sim0-diag(diag(sim0));
sim2=sim1;
sim2(sim2<0.1)=0;
X=(sim1*X_train)./(sim1*A);
x=(sim2*X_train)./(sim2*A);
X(X_test==0)=0;
x(X_test==0)=0;
t=rand(10000,10000)*5;
t(X_test==0)=0;
e1=(X-X_test).^2;
e2=(x-X_test).^2;
e3=(t-X_test).^2;
RMSE1=sqrt(sum(sum(e1))/sum(sum(X_test~=0)));
RMSE2=sqrt(sum(sum(e2))/sum(sum(X_test~=0)));
RMSE3=sqrt(sum(sum(e3))/sum(sum(X_test~=0)));
toc
%%
%k=10,50,100;lambda=0.001,0.01,0.1,1.
k=50;
lambda=0.01;
alpha=0.00001;
U=rand(10000,k)/sqrt(k);%��ʼ��
V=rand(10000,k)/sqrt(k);%��ʼ��
error=X_train-U*V';
temp=A.*error;
J=[];
J(1)=0.5*sum(sum(temp.^2))+lambda*sum(sum(U.^2))+lambda*sum(sum(V.^2));
RMSE=[];
X_P=U*V';
X_P(X_test==0)=0;
e=(X_P-X_test).^2;
RMSE(1)=sqrt(sum(sum(e))/sum(sum(X_test~=0)));
iter=1;
relative_error=10;
%�ݶ��½�����ɢ��������alpha����
while relative_error>0.0001
    J_U=(A.*(U*V'-X_train))*V+2*lambda*U;
    J_V=(A.*(U*V'-X_train))'*U+2*lambda*V;
    U=U-alpha*J_U;
    V=V-alpha*J_V;
    error=X_train-U*V';
    temp=A.*error;
    iter=iter+1;
    J(iter)=0.5*sum(sum(temp.^2))+lambda*sum(sum(U.^2))+lambda*sum(sum(V.^2));
    delta_J=J(iter)-J(iter-1);
    relative_error=abs(delta_J/J(iter-1))
    X_P=U*V';
    X_P(X_test==0)=0;
    e=(X_P-X_test).^2;
    RMSE(iter)=sqrt(sum(sum(e))/sum(sum(X_test~=0)));
end
plot(J);
xlabel('Iteration number');
ylabel('Object function J');
plot(RMSE);
xlabel('Iteration number');
ylabel('RMSE');
grid on;
%% �ݶ��½��������
%k=10,50,100;lambda=0.001,0.01,0.1,1.
A=X_train;
A(A>0)=1;
alpha=0.0001;
j=0;
for k=[10 50 100]
   for lambda=[0.001 0.01 0.1 1]
      U=rand(10000,k)/sqrt(k);
      V=rand(10000,k)/sqrt(k);
      temp=A.*(X_train-U*V');
      J(1)=0.5*sum(sum(temp.^2))+lambda*sum(sum(U.^2))+lambda*sum(sum(V.^2));

%       X_P=U*V';
%       X_P(X_test==0)=0;
%       e=(X_P-X_test).^2;
%       RMSE(1)=sqrt(sum(sum(e))/sum(sum(X_test~=0)));
      iter=1;
      relative_error=10;
      %�ݶ��½�����ɢ��������alpha����
      while relative_error>0.0001
          J_U=(A.*(U*V'-X_train))*V+2*lambda*U;
          J_V=(A.*(U*V'-X_train))'*U+2*lambda*V;
          U=U-alpha*J_U;
          V=V-alpha*J_V;
          temp=A.*(X_train-U*V');
          iter=iter+1;
          J(iter)=0.5*sum(sum(temp.^2))+lambda*sum(sum(U.^2))+lambda*sum(sum(V.^2));
          delta_J=J(iter)-J(iter-1);
          relative_error=abs(delta_J/J(iter-1))
      end
      j=j+1;
      X_P=U*V';
      X_P(X_test==0)=0;
      e=(X_P-X_test).^2;
      iteration(j)=iter;
      RMSE(j)=sqrt(sum(sum(e))/sum(sum(X_test~=0)));
   end
end  
%% item-CF
tic
A=X_train;
A(A>0)=1;
m=vecnorm(X_train);
d=m'*m;
H=X_train'*X_train;
sim0=H./d;
sim1=sim0-diag(diag(sim0));
X=(X_train*sim1)./(A*sim1);
X(X_test==0)=0;
e1=(X-X_test).^2;
RMSE1=sqrt(sum(sum(e1))/sum(sum(X_test~=0)));
toc
%% %%%% Titem-CF %%%%%
% optional�������û����ʱ�����ƷЭͬ����
%%
clear;
tic
T_train=datetime(1995,01,06);
T_test=datetime(1998,09,25);
user=load('users.txt');
T=readtable('netflix_train.txt');
T_t=table2array(T(:,4));
T_u=table2array(T(:,1:3));
P=readtable('netflix_test.txt');
P_u=table2array(P(:,1:3));
P_t=table2array(P(:,4));
n=0
for i=1:10000
    m=find(T_u(:,1)==user(i));
    l=find(P_u(:,1)==user(i));
    T_train(i,T_u(m,2))=T_t(m);
    T_test(i,P_u(l,2))=P_t(l);
    n=n+1;
end
toc
%% ���ʱ�����
T=T_train;
% T0=T_test(1,:);
T(find(isnat(T_test)==0))=T_test(find(isnat(T_test)==0));
% find(isnat(T)==0);
% [R,C]=find(T=='2004-01-01');
T(find(isnat(T)==1))=datetime(2004,01,01);
%% %%%%����ʱ����Ϣ�ĵ����û�����item�����ƶȵ���%%%% %
%������ʱ����Ϣ�����ƶȾ���

A=X_train;
A(A>0)=1;
m=vecnorm(X_train);
d=m'*m;
H=X_train'*X_train;
sim0=H./d;
% ����ʱ��˥������������ƶ�
% a=2;
% b=100;
% c=1;
m=0;

tic
for j=1:10000
% T1=repmat(T(j,:)',1,10000);
% T2=repmat(T(j,:),10000,1);
T3=abs(datenum(repmat(T(j,:)',1,10000))-datenum(repmat(T(j,:),10000,1)));
% f=1./(1+2*T3);
% simItem=sim0.*1./(1+2*T3)-diag(diag(sim0.*1./(1+2*T3)));
% simItem=1./(1+exp(-(a*sim0.*exp(-T3/b)+c)));
% simItem=simItem-diag(diag(simItem));
X(j,:)=(X_train(j,:)*(sim0.*1./(1+2*T3)-diag(diag(sim0.*1./(1+2*T3)))))./...
    (A(j,:)*(sim0.*1./(1+2*T3)-diag(diag(sim0.*1./(1+2*T3)))));
m=m+1
end
toc

% X1=X(1:20,:);
% X2=X_test(1:20,:);
% X1(X2==0)=0;
% e1=(X2-X1).^2;
% RMSE_t=sqrt(sum(sum(e1))/sum(sum(X2~=0)));

X(X_test==0)=0;
e1=(X-X_test).^2;
RMSE_t=sqrt(sum(sum(e1))/sum(sum(X_test~=0)));